import React, { useState } from 'react';

function App() {
  const [empCode, setEmpCode] = useState('');
  const [results, setResults] = useState([]);

  const handleSearch = async () => {
    const res = await fetch(`/search?empCode=${empCode}`);
    const data = await res.json();
    setResults(data);
  };

  return (
    <div style={{ padding: '2rem' }}>
      <h2>Search by Employee Code</h2>
      <input
        type="text"
        value={empCode}
        onChange={(e) => setEmpCode(e.target.value)}
        placeholder="Enter Emp Code"
      />
      <button onClick={handleSearch}>Search</button>

      {results.length > 0 && (
        <table border="1" cellPadding="8" style={{ marginTop: '1rem' }}>
          <thead>
            <tr>
              {Object.keys(results[0]).map((key) => (
                <th key={key}>{key}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {results.map((row, i) => (
              <tr key={i}>
                {Object.values(row).map((val, j) => (
                  <td key={j}>{val}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default App;
